create database Agri_Energy_DB
use Agri_Energy_DB;

CREATE TABLE ForumEntry (
    EntryId INT PRIMARY KEY IDENTITY(1,1),
    EntrySubject NVARCHAR(25) NOT NULL,
    EntryContent NVARCHAR(200) NOT NULL,
    PublishedDate DATE NOT NULL
);

CREATE TABLE Merchandise (
    MerchandiseId INT PRIMARY KEY IDENTITY(1,1),
    MerchandiseName NVARCHAR(50) NOT NULL,
    MerchandiseDescription NVARCHAR(200) NOT NULL,
    ManufactureDate DATE NOT NULL,
    MerchandiseCost NVARCHAR(20) NOT NULL,
    ContactNumber NVARCHAR(15) NOT NULL
);

CREATE TABLE Campaign (
    CampaignId INT PRIMARY KEY IDENTITY(1,1),
    CampaignTitle NVARCHAR(50) NOT NULL,
    CampaignSummary NVARCHAR(700) NOT NULL,
    CoordinatorContact NVARCHAR(15) NOT NULL
);

CREATE TABLE Users
(
    UserId INT PRIMARY KEY IDENTITY(1,1),
    Username NVARCHAR(50) NOT NULL UNIQUE,
    PasswordHash NVARCHAR(256) NOT NULL,
    Email NVARCHAR(100) NOT NULL UNIQUE,
    FullName NVARCHAR(100) NOT NULL,
);


-- Insert satements for ForumEntry Table:
INSERT INTO ForumEntry (EntrySubject, EntryContent, PublishedDate) 
VALUES ('Agriculture Trends', 'Discussion on the latest trends in agriculture.', '2024-05-01');

INSERT INTO ForumEntry (EntrySubject, EntryContent, PublishedDate) 
VALUES ('Sustainable Farming', 'Exploring sustainable farming techniques.', '2024-05-02');

INSERT INTO ForumEntry (EntrySubject, EntryContent, PublishedDate) 
VALUES ('Crop Rotation', 'Benefits and methods of crop rotation.', '2024-05-03');


-- Insert satements for Merchandise Table:
INSERT INTO Merchandise (MerchandiseName, MerchandiseDescription, ManufactureDate, MerchandiseCost, ContactNumber) 
VALUES ('Tractor', 'High efficiency tractor for large farms.', '2023-01-15', '15000 USD', '123-456-7890');

INSERT INTO Merchandise (MerchandiseName, MerchandiseDescription, ManufactureDate, MerchandiseCost, ContactNumber) 
VALUES ('Plough', 'Durable plough for all soil types.', '2023-02-20', '500 USD', '234-567-8901');

INSERT INTO Merchandise (MerchandiseName, MerchandiseDescription, ManufactureDate, MerchandiseCost, ContactNumber) 
VALUES ('Harvester', 'Advanced harvester with high yield capacity.', '2023-03-10', '25000 USD', '345-678-9012');


-- Insert satements for Campaign Table:
INSERT INTO Campaign (CampaignTitle, CampaignSummary, CoordinatorContact) 
VALUES ('Save the Soil', 'A campaign focused on soil conservation and sustainable agriculture practices.', '456-789-0123');

INSERT INTO Campaign (CampaignTitle, CampaignSummary, CoordinatorContact) 
VALUES ('Water for Life', 'Promoting efficient water usage in farming.', '567-890-1234');

INSERT INTO Campaign (CampaignTitle, CampaignSummary, CoordinatorContact) 
VALUES ('Green Future', 'Encouraging the use of renewable energy in agriculture.', '678-901-2345');


-- Insert satements for Users Table:
INSERT INTO Users (Username, PasswordHash, Email, FullName) 
VALUES ('john_doe', 'password123', 'john@example.com', 'John Doe');

INSERT INTO Users (Username, PasswordHash, Email, FullName) 
VALUES ('jane_smith', 'password456', 'jane@example.com', 'Jane Smith');

INSERT INTO Users (Username, PasswordHash, Email, FullName) 
VALUES ('alex_jones', 'password789', 'alex@example.com', 'Alex Jones');

SELECT * FROM ForumEntry;
SELECT * FROM Merchandise;
SELECT * FROM Campaign;
SELECT * FROM Users;